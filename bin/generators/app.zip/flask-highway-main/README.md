# Flask Highway

Basic generic startup Flask App with CLI for interact with some funcionalities