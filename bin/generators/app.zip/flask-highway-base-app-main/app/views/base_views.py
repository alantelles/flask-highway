from dont_touch.core_views import CoreViews

# put here attributes or methods you want to be available to all views
class BaseViews(CoreViews):
    pass