from dont_touch.models_mixins import CoreModel

class BaseModel(CoreModel):
    pass