class CoreViews:
    pass